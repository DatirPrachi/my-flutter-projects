# Zwara Flutter App

A Flutter interview task implementing an influencer listing, search, and product browsing app.

## Features

- **Influencer Listing** — Fetches influencers via POST API with lazy loading and pull-to-refresh
- **Search** — Local-filtered search with 350ms debounce and animated transitions
- **Influencer Detail** — Hero avatar transition, bio, and product list
- **Product Detail** — PageView image carousel, responsive layout via `LayoutBuilder`
- **Error Handling** — Try/catch throughout with `ErrorFallbackWidget` and retry support
- **State Management** — `InheritedWidget` for shared config, `StatefulWidget` + `setState` for local state

## Architecture

```
lib/
├── main.dart
├── core/
│   ├── api_client.dart        # HttpClient wrapper (dart:io, no Dio)
│   ├── exception_handler.dart # Custom exceptions
│   └── app_config.dart        # InheritedWidget for latlon/lang/baseUrl
├── models/
│   ├── influencer.dart
│   └── product.dart
├── screens/
│   ├── influencer_list.dart
│   ├── influencer_detail.dart
│   ├── product_detail.dart
│   └── search_influencer.dart
└── widgets/
    ├── influencer_card.dart
    ├── product_tile.dart
    └── error_fallback.dart
```

## Technical Highlights

- `dart:convert` for JSON parsing — no `json_serializable`
- `HttpClient` (dart:io) — no Dio or http package
- `Material 3` theming — `ThemeData(useMaterial3: true)`
- `Hero` animations for avatar transitions
- `AnimatedSwitcher` + `FadeTransition` on search results
- `AnimatedContainer` for image carousel dots
- `Semantics` + `Tooltip` for accessibility
- `MediaQuery` + `LayoutBuilder` + `Flexible` for responsiveness

## Environment Specs

- Flutter SDK: 3.x.x
- Dart SDK: 3.x.x
- Gradle: 8.x
- Android Gradle Plugin: 8.x
- JDK: 21
- Min SDK: 23
- Target SDK: 34
- Build Variant: release

## Running

```bash
flutter pub get
flutter run
```

## Build APK

```bash
flutter build apk --release
```

## API Endpoints Used

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/v1/influencer-listing` | POST | Fetch influencer list |
| `/api/v1/influencer-details` | GET | Fetch influencer detail |
| `/api/v1/restaurant-search` | POST | Search products |
| `/api/v1/restaurant-detail-v2` | POST | Fetch product detail |

Base URL: `https://api-dev.zwara.co`
Default params: `latlon=29.3677642,47.9705378&lang=en`
