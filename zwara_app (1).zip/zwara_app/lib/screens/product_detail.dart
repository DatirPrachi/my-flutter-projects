import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../core/exception_handler.dart';
import '../models/product.dart';
import '../widgets/error_fallback.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  Product? _detailedProduct;
  bool _isLoading = true;
  String? _error;
  int _currentImageIndex = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isLoading) _loadProduct();
  }

  Future<void> _loadProduct() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final client = ApiClient(context);
      final data = await client.post(
        '/api/v1/restaurant-detail-v2',
        body: {
          'search': '',
          'category_id': '',
          'latlon': '29.3677642,47.9705378',
          'user_id': '',
          'id': widget.product.id,
        },
        queryParams: {'id': widget.product.id},
      );

      final productData = data['data'] ?? data['product'] ?? {};
      setState(() {
        _detailedProduct = productData.isNotEmpty
            ? Product.fromJson(productData)
            : widget.product;
        _isLoading = false;
      });
    } catch (e) {
      final ex = ExceptionHandler.handle(e);
      setState(() {
        _error = ex.message;
        _isLoading = false;
        _detailedProduct = widget.product;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final product = _detailedProduct ?? widget.product;

    return Scaffold(
      appBar: AppBar(title: Text(product.name)),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(product),
    );
  }

  Widget _buildContent(Product product) {
    if (_error != null && _detailedProduct == null) {
      return ErrorFallbackWidget(message: _error!, onRetry: _loadProduct);
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth > 600;
        final content = _buildDetails(product, constraints);
        return isWide
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: _buildCarousel(product, 400)),
                  Expanded(child: SingleChildScrollView(child: content)),
                ],
              )
            : SingleChildScrollView(
                child: Column(
                  children: [
                    _buildCarousel(product, 260),
                    content,
                  ],
                ),
              );
      },
    );
  }

  Widget _buildCarousel(Product product, double height) {
    final images = product.images;
    if (images.isEmpty) {
      return Container(
        height: height,
        color: Colors.grey[200],
        child: const Icon(Icons.fastfood, size: 80, color: Colors.grey),
      );
    }
    return SizedBox(
      height: height,
      child: Stack(
        children: [
          PageView.builder(
            itemCount: images.length,
            onPageChanged: (i) => setState(() => _currentImageIndex = i),
            itemBuilder: (context, index) {
              return Image.network(
                images[index],
                fit: BoxFit.cover,
                width: double.infinity,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.broken_image, size: 60),
              );
            },
          ),
          if (images.length > 1)
            Positioned(
              bottom: 12,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  images.length,
                  (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: _currentImageIndex == i ? 16 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _currentImageIndex == i
                          ? Colors.white
                          : Colors.white54,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDetails(Product product, BoxConstraints constraints) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(product.name,
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(
            '\$${product.price.toStringAsFixed(2)}',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                ),
          ),
          if (product.influencerName != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.person_outline, size: 16),
                const SizedBox(width: 4),
                Text('By ${product.influencerName}',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ],
          const SizedBox(height: 16),
          Text('Description',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(product.description.isNotEmpty
              ? product.description
              : 'No description available.'),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                'Note: Showing cached data. ${_error!}',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: Colors.orange),
              ),
            ),
        ],
      ),
    );
  }
}
