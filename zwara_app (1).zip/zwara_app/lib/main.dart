import 'package:flutter/material.dart';
import 'core/app_config.dart';
import 'screens/influencer_list.dart';

void main() {
  runApp(const ZwaraApp());
}

class ZwaraApp extends StatelessWidget {
  const ZwaraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AppConfig(
      child: MaterialApp(
        title: 'Zwara',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF6C63FF),
          fontFamily: 'Roboto',
        ),
        home: const InfluencerListScreen(),
      ),
    );
  }
}
