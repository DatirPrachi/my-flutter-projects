abstract class ApiClientBase {
  Future<Map<String, dynamic>> get(String path,
      {Map<String, String>? queryParams});

  Future<Map<String, dynamic>> post(String path,
      {Map<String, dynamic>? body, Map<String, String>? queryParams});
}
