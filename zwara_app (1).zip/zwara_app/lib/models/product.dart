class Product {
  final String id;
  final String name;
  final String description;
  final List<String> images;
  final double price;
  final String? influencerName;
  final String? influencerId;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.images,
    required this.price,
    this.influencerName,
    this.influencerId,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    List<String> imgs = [];
    if (json['images'] is List) {
      imgs = (json['images'] as List).map((e) => e.toString()).toList();
    } else if (json['image'] != null) {
      imgs = [json['image'].toString()];
    }

    return Product(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? 'Unknown',
      description: json['description']?.toString() ?? '',
      images: imgs,
      price: double.tryParse(json['price']?.toString() ?? '0') ?? 0.0,
      influencerName: json['influencer_name']?.toString(),
      influencerId: json['influencer_id']?.toString(),
    );
  }
}
