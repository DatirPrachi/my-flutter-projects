import 'package:flutter/material.dart';
import '../models/influencer.dart';

class InfluencerCard extends StatelessWidget {
  final Influencer influencer;
  final VoidCallback onTap;

  const InfluencerCard({
    super.key,
    required this.influencer,
    required this.onTap,
  });

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'online':
      case 'active':
        return Colors.green;
      case 'busy':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Influencer ${influencer.name}, status ${influencer.status}',
      button: true,
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: Hero(
            tag: 'avatar_${influencer.id}',
            child: CircleAvatar(
              radius: 28,
              backgroundImage: influencer.avatar.isNotEmpty
                  ? NetworkImage(influencer.avatar)
                  : null,
              child: influencer.avatar.isEmpty
                  ? Text(influencer.name.isNotEmpty
                      ? influencer.name[0].toUpperCase()
                      : '?')
                  : null,
            ),
          ),
          title: Text(
            influencer.name,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          subtitle: Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: _statusColor(influencer.status),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                influencer.status,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      ),
    );
  }
}
