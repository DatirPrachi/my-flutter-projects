import 'package:flutter/material.dart';

class AppConfig extends InheritedWidget {
  final String latlon;
  final String lang;
  final String baseUrl;

  const AppConfig({
    super.key,
    required super.child,
    this.latlon = '29.3677642,47.9705378',
    this.lang = 'en',
    this.baseUrl = 'https://api-dev.zwara.co',
  });

  static AppConfig of(BuildContext context) {
    final config = context.dependOnInheritedWidgetOfExactType<AppConfig>();
    assert(config != null, 'No AppConfig found in context');
    return config!;
  }

  @override
  bool updateShouldNotify(AppConfig oldWidget) {
    return latlon != oldWidget.latlon || lang != oldWidget.lang;
  }
}
