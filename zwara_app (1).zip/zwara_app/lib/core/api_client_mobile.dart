import 'dart:convert';
import 'dart:io';
import 'api_client_interface.dart';
import 'exception_handler.dart';

class PlatformApiClient implements ApiClientBase {
  final String baseUrl;
  final String latlon;
  final String lang;

  PlatformApiClient({
    required this.baseUrl,
    required this.latlon,
    required this.lang,
  });

  Map<String, String> get _defaultParams => {
        'latlon': latlon,
        'lang': lang,
      };

  @override
  Future<Map<String, dynamic>> get(String path,
      {Map<String, String>? queryParams}) async {
    final params = {..._defaultParams, ...?queryParams};
    final uri = Uri.parse('$baseUrl$path').replace(queryParameters: params);

    final client = HttpClient();
    try {
      final request = await client.getUrl(uri);
      request.headers.set('Content-Type', 'application/json');
      final response = await request.close();
      final body = await response.transform(utf8.decoder).join();

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return json.decode(body) as Map<String, dynamic>;
      } else {
        throw NetworkException('Server error: ${response.statusCode}',
            statusCode: response.statusCode);
      }
    } on SocketException {
      throw NetworkException('No internet connection');
    } on FormatException {
      throw ParseException('Failed to parse response');
    } finally {
      client.close();
    }
  }

  @override
  Future<Map<String, dynamic>> post(String path,
      {Map<String, dynamic>? body,
      Map<String, String>? queryParams}) async {
    final params = {..._defaultParams, ...?queryParams};
    final uri = Uri.parse('$baseUrl$path').replace(queryParameters: params);

    final client = HttpClient();
    try {
      final request = await client.postUrl(uri);
      request.headers.set('Content-Type', 'application/json');
      if (body != null) {
        request.write(json.encode(body));
      }
      final response = await request.close();
      final responseBody = await response.transform(utf8.decoder).join();

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return json.decode(responseBody) as Map<String, dynamic>;
      } else {
        throw NetworkException('Server error: ${response.statusCode}',
            statusCode: response.statusCode);
      }
    } on SocketException {
      throw NetworkException('No internet connection');
    } on FormatException {
      throw ParseException('Failed to parse response');
    } finally {
      client.close();
    }
  }
}
