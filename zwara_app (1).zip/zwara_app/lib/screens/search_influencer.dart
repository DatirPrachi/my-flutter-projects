import 'dart:async';
import 'package:flutter/material.dart';
import '../models/influencer.dart';
import '../widgets/influencer_card.dart';
import 'influencer_detail.dart';

class SearchInfluencerScreen extends StatefulWidget {
  final List<Influencer> influencers;

  const SearchInfluencerScreen({super.key, required this.influencers});

  @override
  State<SearchInfluencerScreen> createState() =>
      _SearchInfluencerScreenState();
}

class _SearchInfluencerScreenState extends State<SearchInfluencerScreen> {
  final TextEditingController _controller = TextEditingController();
  Timer? _debounce;
  List<Influencer> _results = [];
  bool _hasSearched = false;

  @override
  void initState() {
    super.initState();
    _results = widget.influencers;
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      final q = query.toLowerCase().trim();
      setState(() {
        _hasSearched = true;
        if (q.isEmpty) {
          _results = widget.influencers;
        } else {
          _results = widget.influencers
              .where((i) =>
                  i.name.toLowerCase().contains(q) ||
                  i.status.toLowerCase().contains(q))
              .toList();
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Semantics(
          label: 'Search influencers input',
          child: TextField(
            controller: _controller,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Search influencers...',
              border: InputBorder.none,
            ),
            onChanged: _onSearchChanged,
          ),
        ),
        actions: [
          if (_controller.text.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear),
              onPressed: () {
                _controller.clear();
                _onSearchChanged('');
              },
            )
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: _buildResults(),
      ),
    );
  }

  Widget _buildResults() {
    if (_results.isEmpty && _hasSearched) {
      return const Center(
        key: ValueKey('empty'),
        child: Text('No influencers match your search.'),
      );
    }
    return ListView.builder(
      key: ValueKey(_results.length),
      itemCount: _results.length,
      itemBuilder: (context, index) {
        return FadeTransition(
          opacity: const AlwaysStoppedAnimation(1.0),
          child: InfluencerCard(
            influencer: _results[index],
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      InfluencerDetailScreen(influencer: _results[index]),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
