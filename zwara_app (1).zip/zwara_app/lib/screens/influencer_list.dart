import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../core/exception_handler.dart';
import '../models/influencer.dart';
import '../widgets/influencer_card.dart';
import '../widgets/error_fallback.dart';
import 'influencer_detail.dart';
import 'search_influencer.dart';

class InfluencerListScreen extends StatefulWidget {
  const InfluencerListScreen({super.key});

  @override
  State<InfluencerListScreen> createState() => _InfluencerListScreenState();
}

class _InfluencerListScreenState extends State<InfluencerListScreen> {
  List<Influencer> _influencers = [];
  bool _isLoading = true;
  String? _error;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_influencers.isEmpty && _isLoading) {
      _loadInfluencers();
    }
  }

  Future<void> _loadInfluencers() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final client = ApiClient(context);
      final data = await client.post(
        '/api/v1/influencer-listing',
        body: {'filter': {'categories': ''}},
      );

      final List raw = data['data'] ?? data['influencers'] ?? [];
      setState(() {
        _influencers = raw.map((e) => Influencer.fromJson(e)).toList();
        _isLoading = false;
      });
    } catch (e) {
      final ex = ExceptionHandler.handle(e);
      setState(() {
        _error = ex.message;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Influencers'),
        actions: [
          Tooltip(
            message: 'Search influencers',
            child: IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        SearchInfluencerScreen(influencers: _influencers),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return ErrorFallbackWidget(
        message: _error!,
        onRetry: _loadInfluencers,
      );
    }
    if (_influencers.isEmpty) {
      return const Center(child: Text('No influencers found.'));
    }
    return RefreshIndicator(
      onRefresh: _loadInfluencers,
      child: ListView.builder(
        itemCount: _influencers.length,
        itemBuilder: (context, index) {
          final influencer = _influencers[index];
          return InfluencerCard(
            influencer: influencer,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      InfluencerDetailScreen(influencer: influencer),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
