// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'dart:convert';
import 'api_client_interface.dart';
import 'exception_handler.dart';

class PlatformApiClient implements ApiClientBase {
  final String baseUrl;
  final String latlon;
  final String lang;

  PlatformApiClient({
    required this.baseUrl,
    required this.latlon,
    required this.lang,
  });

  Map<String, String> get _defaultParams => {
        'latlon': latlon,
        'lang': lang,
      };

  String _buildUrl(String path, Map<String, String>? queryParams) {
    final params = {..._defaultParams, ...?queryParams};
    return Uri.parse('$baseUrl$path')
        .replace(queryParameters: params)
        .toString();
  }

  Future<Map<String, dynamic>> _send(
    String method,
    String url, {
    Map<String, dynamic>? body,
  }) async {
    final completer = html.HttpRequest();
    completer.open(method, url, async: true);
    completer.setRequestHeader('Content-Type', 'application/json');

    final future = completer.onLoad.first;
    if (body != null) {
      completer.send(json.encode(body));
    } else {
      completer.send();
    }

    await future;

    final status = completer.status ?? 0;
    if (status >= 200 && status < 300) {
      try {
        return json.decode(completer.responseText ?? '{}')
            as Map<String, dynamic>;
      } on FormatException {
        throw ParseException('Failed to parse response');
      }
    } else if (status == 0) {
      throw NetworkException('No internet connection or CORS error');
    } else {
      throw NetworkException('Server error: $status', statusCode: status);
    }
  }

  @override
  Future<Map<String, dynamic>> get(String path,
      {Map<String, String>? queryParams}) async {
    final url = _buildUrl(path, queryParams);
    return _send('GET', url);
  }

  @override
  Future<Map<String, dynamic>> post(String path,
      {Map<String, dynamic>? body,
      Map<String, String>? queryParams}) async {
    final url = _buildUrl(path, queryParams);
    return _send('POST', url, body: body);
  }
}
