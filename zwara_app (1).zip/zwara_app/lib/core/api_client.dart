import 'package:flutter/material.dart';
import 'app_config.dart';
import 'api_client_interface.dart';

// Conditional imports: uses web impl on web, mobile impl everywhere else
import 'api_client_mobile.dart'
    if (dart.library.html) 'api_client_web.dart';

export 'api_client_interface.dart';

/// Factory that creates the correct platform-specific HTTP client.
/// Usage: `final client = ApiClient(context);`
class ApiClient implements ApiClientBase {
  late final ApiClientBase _impl;

  ApiClient(BuildContext context) {
    final config = AppConfig.of(context);
    _impl = PlatformApiClient(
      baseUrl: config.baseUrl,
      latlon: config.latlon,
      lang: config.lang,
    );
  }

  @override
  Future<Map<String, dynamic>> get(String path,
          {Map<String, String>? queryParams}) =>
      _impl.get(path, queryParams: queryParams);

  @override
  Future<Map<String, dynamic>> post(String path,
          {Map<String, dynamic>? body,
          Map<String, String>? queryParams}) =>
      _impl.post(path, body: body, queryParams: queryParams);
}
