class AppException implements Exception {
  final String message;
  final int? statusCode;

  AppException(this.message, {this.statusCode});

  @override
  String toString() => 'AppException: $message (status: $statusCode)';
}

class NetworkException extends AppException {
  NetworkException(super.message, {super.statusCode});
}

class ParseException extends AppException {
  ParseException(super.message);
}

class ExceptionHandler {
  static AppException handle(dynamic error) {
    if (error is AppException) return error;
    return AppException(error.toString());
  }
}
