class Influencer {
  final String id;
  final String name;
  final String avatar;
  final String status;
  final String? bio;

  Influencer({
    required this.id,
    required this.name,
    required this.avatar,
    required this.status,
    this.bio,
  });

  factory Influencer.fromJson(Map<String, dynamic> json) {
    return Influencer(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? 'Unknown',
      avatar: json['avatar']?.toString() ?? '',
      status: json['status']?.toString() ?? 'offline',
      bio: json['bio']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'avatar': avatar,
        'status': status,
        'bio': bio,
      };
}
