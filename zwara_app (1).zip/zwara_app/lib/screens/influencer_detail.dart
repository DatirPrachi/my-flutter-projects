import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../core/exception_handler.dart';
import '../models/influencer.dart';
import '../models/product.dart';
import '../widgets/product_tile.dart';
import '../widgets/error_fallback.dart';
import 'product_detail.dart';

class InfluencerDetailScreen extends StatefulWidget {
  final Influencer influencer;

  const InfluencerDetailScreen({super.key, required this.influencer});

  @override
  State<InfluencerDetailScreen> createState() =>
      _InfluencerDetailScreenState();
}

class _InfluencerDetailScreenState extends State<InfluencerDetailScreen> {
  Influencer? _detailedInfluencer;
  List<Product> _products = [];
  bool _isLoading = true;
  String? _error;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isLoading) _loadDetails();
  }

  Future<void> _loadDetails() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final client = ApiClient(context);
      final data = await client.get(
        '/api/v1/influencer-details',
        queryParams: {'influencer_id': widget.influencer.id},
      );

      final influencerData = data['data'] ?? data['influencer'] ?? {};
      final productsList = data['products'] ?? influencerData['products'] ?? [];

      setState(() {
        _detailedInfluencer = influencerData.isNotEmpty
            ? Influencer.fromJson(influencerData)
            : widget.influencer;
        _products = (productsList as List)
            .map((e) => Product.fromJson(e))
            .toList();
        _isLoading = false;
      });
    } catch (e) {
      final ex = ExceptionHandler.handle(e);
      setState(() {
        _error = ex.message;
        _isLoading = false;
        _detailedInfluencer = widget.influencer;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final influencer = _detailedInfluencer ?? widget.influencer;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(influencer.name),
              background: influencer.avatar.isNotEmpty
                  ? Image.network(influencer.avatar, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          const ColoredBox(color: Colors.grey))
                  : const ColoredBox(color: Colors.grey),
            ),
            leading: const BackButton(),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Hero(
                      tag: 'avatar_${influencer.id}',
                      child: CircleAvatar(
                        radius: 48,
                        backgroundImage: influencer.avatar.isNotEmpty
                            ? NetworkImage(influencer.avatar)
                            : null,
                        child: influencer.avatar.isEmpty
                            ? Text(
                                influencer.name.isNotEmpty
                                    ? influencer.name[0].toUpperCase()
                                    : '?',
                                style: const TextStyle(fontSize: 32),
                              )
                            : null,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (influencer.bio != null && influencer.bio!.isNotEmpty) ...[
                    Text('About',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Text(influencer.bio!),
                    const SizedBox(height: 16),
                  ],
                  Text('Products',
                      style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            ),
          ),
          if (_isLoading)
            const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()))
          else if (_error != null && _products.isEmpty)
            SliverFillRemaining(
              child: ErrorFallbackWidget(
                message: _error!,
                onRetry: _loadDetails,
              ),
            )
          else if (_products.isEmpty)
            const SliverFillRemaining(
                child: Center(child: Text('No products available.')))
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  return ProductTile(
                    product: _products[index],
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProductDetailScreen(
                            product: _products[index],
                          ),
                        ),
                      );
                    },
                  );
                },
                childCount: _products.length,
              ),
            ),
        ],
      ),
    );
  }
}
